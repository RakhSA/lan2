"use strict";

function foo() {
  console.log("TEST");
}
